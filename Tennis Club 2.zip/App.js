import '@fortawesome/fontawesome-free/css/all.min.css';
import './style.css';
import Marquee from './Marquee';
import court from './image/court.webp'; 
import name from './image/name.svg'; 
import logo from './image/logo.svg';
import about from './image/about.webp';
const App= () => {
  return (
    <div>
      <div>
      <div>
        <img src={court} alt="court" className="court"/>
        <img src={name} alt="name" className="name"/>
        <i class="pointer down fa-solid fa-angle-down"></i>
      </div>
      <div className="box">
        <h3>BOOK A COURT</h3>
      </div>
      </div>
      <div className="logo-container">
        <img src={logo} alt="logo" className="logo"/>
        <p className="welcome">Welcome to the sporting heart of Sóller.</p>
        <p className="description">Sóller Tennis Club is a wellness and lifestyle community for local neighbours, international friends and touring pros. </p>
      </div>
      <div className="flexrow">
        <img src={about} alt="about" className="about-img"/>
        <p className="about-text">
        A one-of-a-kind destination where tennis, padel and swimming are metres away from a relaxed restaurant and panoramic views across the UNESCO World Heritage Serra de Tramuntana.
        <br /><br />
        Perched high between mountains and sea, our club overlooks the historic town of Sóller – highlighting one of the most beautiful courtside views anywhere in Europe.
        </p>
      </div>
      <div>
      <Marquee />
      </div>
        <h2 className='txt-h2  txt1'>
          Arrive for the game.
        </h2>
        <h2 className='txt-h2  txt2'>
          Stay for the day.
        </h2>
        <h2 className='txt-h2  txt3'>
          Return for the moments.
        </h2>
        <p className='txt-p'>
          Our grounds are carved into a hillside that’s drenched in sunshine with dappled shade, where clean coastal air is filtered through cool mountains. Twisting paths amble through fragrant lemon and orange trees, connecting a variety of lounge spaces – from comfortable seating and family picnic areas to hidden corners where you can be alone with nature.
        </p>
        <div className='txt'>
          <h2 className='txt2-h2 txt2-1'>
            Sociable spaces and quiet corners.
          </h2>
          <h2 className='txt2-h2 txt2-2'>
            Find your place.
          </h2>
        </div>
      





    </div>
  );
};

export default App ;






