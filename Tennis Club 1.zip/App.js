import '@fortawesome/fontawesome-free/css/all.min.css';
import './style.css';


import court from './image/court.webp'; 
import name from './image/name.svg'; 
import logo from './image/logo.svg';
import about from './image/about.webp';
const App= () => {
  return (
    <div className = "background">
      <div>
      <div>
        <img src={court} alt="court" className="court"/>
        <img src={name} alt="name" className="name"/>
        <i class="pointer down fa-solid fa-angle-down"></i>
      </div>
      <div className="box">
        <h3>BOOK A COURT</h3>
      </div>
      </div>
      <div className="logo-container">
        <img src={logo} alt="logo" className="logo"/>
        <p className="welcome">Welcome to the sporting heart of Sóller.</p>
        <p className="description">Sóller Tennis Club is a wellness and lifestyle community for local neighbours, international friends and touring pros. </p>
      </div>
      <div className="flexrow">
        <img src={about} alt="about" className="about-img"/>
        <p className="about-text">
        A one-of-a-kind destination where tennis, padel and swimming are metres away from a relaxed restaurant and panoramic views across the UNESCO World Heritage Serra de Tramuntana.
        <br /><br />
        Perched high between mountains and sea, our club overlooks the historic town of Sóller – highlighting one of the most beautiful courtside views anywhere in Europe.
        </p>
      </div>
    </div>
  );
};

export default App ;






